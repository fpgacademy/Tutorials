#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <limits.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include "alt_up_pci_lib.h"
#include "timeMeasure_RDTSC.h"

#define DATA_SIZE 4096 * 8
#define CTRLLER_ID 1

#define TRANS_NUM 2

int main() {

	int fd, use_interrupt = INTERRUPT;
	char buff[DATA_SIZE], buff_rd[DATA_SIZE];

	int i,j;
	double freq = 2833.0*1e6;
	uint64_t start,stop; 

	// Open the device file
	if( alt_up_pci_open(&fd, "/dev/alt_up_pci0") ){
		return 0;
	}

	srand((unsigned)time(NULL));

	for(j = 0; j < TRANS_NUM; j++) {

		//  
		for(i = 0; i < DATA_SIZE; i++){
			buff[i] = rand()%1024+1;
			buff_rd[i] = 0;
		}

		// set dma
		alt_up_pci_dma_add(fd, CTRLLER_ID, 0x0,         buff,               DATA_SIZE/2, TO_DEVICE);
		alt_up_pci_dma_add(fd, CTRLLER_ID, DATA_SIZE/2, buff + DATA_SIZE/2, DATA_SIZE/2, TO_DEVICE);

		// dma go
		start = get_rdtsc();
		alt_up_pci_dma_go (fd, CTRLLER_ID, use_interrupt);
		stop = get_rdtsc();
		printf("DMA-Write Band: %lf\n",(double)(DATA_SIZE)/(stop-start)*freq);

		// set dma
		alt_up_pci_dma_add(fd, CTRLLER_ID, 0x0, buff_rd, DATA_SIZE, FROM_DEVICE);

		// dma go
		start = get_rdtsc();
		alt_up_pci_dma_go (fd, CTRLLER_ID, use_interrupt);
		stop = get_rdtsc();
		printf("DMA-Read Band : %lf\n",(double)(DATA_SIZE)/(stop-start)*freq);


		// Check value 
		int fail_count=0;
		for(i=0;i<DATA_SIZE;i++) {
			if(buff[i] != buff_rd[i]){
				fail_count++;
			}
		}

		printf("fail_count: %d\n",fail_count);

		use_interrupt = POLLING;
	}

	printf("\n");

	
	// start testing PIO write/read
	for(i=0;i<DATA_SIZE;i++) {
		buff[i] = i%256;
		buff_rd[i] = 0;
	}

	// write
	start = get_rdtsc();
	alt_up_pci_write(fd, BAR0, 0x0,                   buff,                   sizeof(char)* ( DATA_SIZE - 1));
	alt_up_pci_write(fd, BAR0, 0x0 + (DATA_SIZE - 1), buff + (DATA_SIZE - 1), sizeof(char)*1);
	stop = get_rdtsc();
	printf("PIO-Write Band: %lf\n",(double)(DATA_SIZE)/(stop-start)*freq);

	// read
	start = get_rdtsc();
	alt_up_pci_read (fd, BAR0, 0x0, buff_rd, sizeof(char)*(DATA_SIZE));
	stop = get_rdtsc();
	printf("PIO-Read Band : %lf\n",(double)(DATA_SIZE)/(stop-start)*freq);

	/* Check value */
	int count =0;
	for(i=0;i<DATA_SIZE;i++) {
		if(buff[i] != buff_rd[i]){
			count++;
		}
	}

	printf("fail_count: %d\n",count);


	printf("\nTests for errors.\n");

	// error checking
	if( alt_up_pci_write(fd, 7, 0x0, buff, sizeof(char)*DATA_SIZE) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_read(fd, BAR0, 0x1, buff, sizeof(char)*DATA_SIZE) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_write(fd, BAR0, -1, buff, sizeof(char)*DATA_SIZE) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_write(fd, BAR0, 0x0, NULL, sizeof(char)*DATA_SIZE) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_read(fd, BAR0, 0x0, buff, -1) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_dma_add(fd, 4, 0x0, buff, DATA_SIZE/2, TO_DEVICE) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");

	if( alt_up_pci_dma_add(fd, CTRLLER_ID, 0x0, buff, DATA_SIZE/2, 2) != -1 )
		printf("Fail\n");
	else printf("--> Pass\n");



	// close
	alt_up_pci_close(fd);

	return 0;
}
